import { createHash, timingSafeEqual } from 'node:crypto';
import { getApps, initializeApp, cert } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, Timestamp, FieldValue } from 'firebase-admin/firestore';

const SESSION_MINUTES = 15;
const MAX_ATTEMPTS = 5;
const ATTEMPT_WINDOW_MS = 15 * 60 * 1000;
const BLOCK_WINDOW_MS = 15 * 60 * 1000;

function services() {
  if (!process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
    throw new Error('FIREBASE_SERVICE_ACCOUNT_JSON environment variable is not configured.');
  }
  if (!getApps().length) {
    const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON);
    initializeApp({
      credential: cert(serviceAccount),
      projectId: process.env.FIREBASE_PROJECT_ID || serviceAccount.project_id || 'studyflownova'
    });
  }
  return { auth: getAuth(), db: getFirestore() };
}
function response(statusCode, payload) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store, max-age=0',
      'X-Content-Type-Options': 'nosniff'
    },
    body: JSON.stringify(payload)
  };
}
function safeEqual(value, expected) {
  // Hash first so timingSafeEqual compares fixed-length buffers without leaking secret length.
  const left = createHash('sha256').update(String(value), 'utf8').digest();
  const right = createHash('sha256').update(String(expected), 'utf8').digest();
  return timingSafeEqual(left, right) && String(value) === String(expected);
}
async function getVerifiedUser(event, auth) {
  const header = event.headers?.authorization || event.headers?.Authorization || '';
  const match = /^Bearer\s+(.+)$/i.exec(header);
  if (!match) throw Object.assign(new Error('Sign in is required.'), { statusCode: 401 });
  return auth.verifyIdToken(match[1], true);
}
async function checkRateLimit(db, uid) {
  const ref = db.collection('adminLoginAttempts').doc(uid);
  const now = Date.now();
  return db.runTransaction(async tx => {
    const snap = await tx.get(ref);
    const data = snap.exists ? snap.data() : {};
    const blockedUntil = data.blockedUntil?.toMillis?.() || 0;
    if (blockedUntil > now) return { allowed: false, retryAfterSeconds: Math.ceil((blockedUntil - now) / 1000) };
    const start = data.windowStart?.toMillis?.() || 0;
    const inWindow = start > 0 && now - start < ATTEMPT_WINDOW_MS;
    const attempts = inWindow ? Number(data.attempts || 0) : 0;
    return { allowed: true, ref, attempts, windowStart: inWindow ? data.windowStart : Timestamp.fromMillis(now) };
  });
}
async function recordFailure(db, attempt) {
  const nextCount = attempt.attempts + 1;
  const now = Date.now();
  const blockedUntil = nextCount >= MAX_ATTEMPTS ? Timestamp.fromMillis(now + BLOCK_WINDOW_MS) : null;
  await attempt.ref.set({
    attempts: nextCount,
    windowStart: attempt.windowStart,
    lastAttemptAt: FieldValue.serverTimestamp(),
    ...(blockedUntil ? { blockedUntil } : {})
  }, { merge: true });
  return blockedUntil ? BLOCK_WINDOW_MS / 1000 : 0;
}

export const handler = async event => {
  if (event.httpMethod === 'OPTIONS') return response(204, {});
  if (event.httpMethod !== 'POST') return response(405, { message: 'Use POST for this endpoint.' });
  let payload;
  try { payload = JSON.parse(event.body || '{}'); }
  catch { return response(400, { message: 'Invalid request body.' }); }
  if (!['login', 'logout'].includes(payload.action)) return response(400, { message: 'Unknown admin-session action.' });

  let ctx;
  try { ctx = services(); }
  catch (error) {
    console.error('Admin function is not configured:', error.message);
    return response(500, { message: 'Admin server setup is incomplete. Configure the required Netlify environment variables.' });
  }
  let decoded;
  try { decoded = await getVerifiedUser(event, ctx.auth); }
  catch (error) { return response(error.statusCode || 401, { message: 'Your Google sign-in session is invalid or expired. Sign in again.' }); }
  if (decoded.firebase?.sign_in_provider !== 'google.com') {
    return response(403, { message: 'Admin access requires a verified Google sign-in.' });
  }

  const sessionRef = ctx.db.collection('adminSessions').doc(decoded.uid);
  if (payload.action === 'logout') {
    try {
      await sessionRef.delete();
      await ctx.db.collection('adminLoginAttempts').doc(decoded.uid).delete().catch(() => {});
      return response(200, { ok: true, role: 'user' });
    } catch (error) {
      console.error('Could not clear admin session:', error);
      return response(500, { message: 'Could not clear the admin session; it will expire automatically.' });
    }
  }

  const expected = process.env.STUDYFLOW_ADMIN_PASSWORD;
  if (!expected) return response(500, { message: 'Admin password is not configured in Netlify environment variables.' });
  if (typeof payload.password !== 'string' || payload.password.length < 1 || payload.password.length > 256) {
    return response(400, { message: 'Enter the admin password.' });
  }
  let attempt;
  try { attempt = await checkRateLimit(ctx.db, decoded.uid); }
  catch (error) {
    console.error('Admin rate-limit check failed:', error);
    return response(500, { message: 'Could not verify admin access right now.' });
  }
  if (!attempt.allowed) return response(429, { message: `Too many attempts. Try again in about ${Math.ceil(attempt.retryAfterSeconds / 60)} minute(s).` });
  if (!safeEqual(payload.password, expected)) {
    const retryAfter = await recordFailure(ctx.db, attempt).catch(error => { console.error('Could not record admin login attempt:', error); return 0; });
    if (retryAfter) return response(429, { message: 'Too many incorrect attempts. Admin access is temporarily locked.' });
    return response(401, { message: 'Admin password was not accepted.' });
  }

  try {
    await ctx.db.collection('adminLoginAttempts').doc(decoded.uid).delete().catch(() => {});
    const expiresAt = Timestamp.fromMillis(Date.now() + SESSION_MINUTES * 60 * 1000);
    await sessionRef.set({
      uid: decoded.uid,
      role: 'admin',
      createdAt: FieldValue.serverTimestamp(),
      expiresAt
    });
    return response(200, { ok: true, role: 'admin', expiresInMinutes: SESSION_MINUTES });
  } catch (error) {
    console.error('Could not create admin session:', error);
    return response(500, { message: 'Could not activate admin mode. Please try again.' });
  }
};
